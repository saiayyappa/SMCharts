package com.example.stockspring.service;

import com.example.stockspring.model.Userdb;

public interface LoginService {

	public Userdb login(Userdb user) throws Exception;
}

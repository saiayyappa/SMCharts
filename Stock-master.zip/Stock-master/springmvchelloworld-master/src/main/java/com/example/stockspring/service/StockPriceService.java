package com.example.stockspring.service;

import java.util.List;

import com.example.stockspring.model.StockPrice;

public interface StockPriceService {

	public List<StockPrice> stockPriceList();

}

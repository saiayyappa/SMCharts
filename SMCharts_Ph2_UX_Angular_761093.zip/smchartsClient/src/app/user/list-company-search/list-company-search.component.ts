import { Component, OnInit } from '@angular/core';
import { Company } from 'src/app/models/company';
import { CompanyService } from 'src/app/service/company.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-list-company-search',
  templateUrl: './list-company-search.component.html',
  styleUrls: ['./list-company-search.component.css']
})
export class ListCompanySearchComponent implements OnInit {
  constructor() { }

  ngOnInit() {
  }

}

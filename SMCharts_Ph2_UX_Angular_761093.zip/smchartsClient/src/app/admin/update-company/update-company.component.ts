import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { Company } from 'src/app/models/company';
import { StockExchange } from 'src/app/models/stockExchange';
import { Sector } from 'src/app/models/sector';
import { Router, ActivatedRoute } from '@angular/router';
import { SectorService } from 'src/app/service/sector.service';
import { StockExchangeService } from 'src/app/service/stock-exchange.service';
import { CompanyService } from 'src/app/service/company.service';

@Component({
  selector: 'update-company',
  templateUrl: './update-company.component.html',
  styleUrls: ['./update-company.component.css']
})
export class UpdateCompanyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
}

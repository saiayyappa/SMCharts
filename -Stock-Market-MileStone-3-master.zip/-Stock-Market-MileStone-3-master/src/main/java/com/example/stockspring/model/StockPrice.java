package com.example.stockspring.model;



import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;

@Entity
@Table(name = "stock_price")
public class StockPrice {

	@Id
	@Column(name = "stock_code")
	private int stockCode;

	@Column(name = "company_code")
	private int companyCode;

	@Column(name = "stock_exchange")
	private int stockExchange;

	/*
	 * @ManyToOne(cascade = CascadeType.ALL)
	 * 
	 * @JoinColumn(name = "company_code") private Company company;
	 * 
	 * public Company getCompany() { return company; }
	 * 
	 * public void setCompany(Company company) { this.company = company; }
	 * 
	 * @ManyToOne(cascade = CascadeType.ALL)
	 * 
	 * @JoinColumn(name = "stock_exchange") private StockExchange stockExchange;
	 * 
	 * 
	 * 
	 * public StockExchange getStockExchange() { return stockExchange; }
	 * 
	 * public void setStockExchange(StockExchange stockExchange) {
	 * this.stockExchange = stockExchange; }
	 */

	@NotEmpty(message = "Please enter CurrentPrice")
	@Column(name = "current_price")
	private double currentPrice;

	@NotEmpty(message = "Please enter Date")
	@Column(name = "date")
	private Date date;

	@NotEmpty(message = "Please enter Time")
	@Column(name = "time")
	private String time;

	public double getCurrentPrice() {
		return currentPrice;
	}

	public void setCurrentPrice(double currentPrice) {
		this.currentPrice = currentPrice;
	}

	

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public int getStockCode() {
		return stockCode;
	}

	public void setStockCode(int stockCode) {
		this.stockCode = stockCode;
	}

	public int getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(int companyCode) {
		this.companyCode = companyCode;
	}

	public int getStockExchange() {
		return stockExchange;
	}

	public void setStockExchange(int stockExchange) {
		this.stockExchange = stockExchange;
	}

	@Override
	public String toString() {
		return "StockPrice [stockCode=" + stockCode + ", company=" + companyCode + ", stockExchange=" + stockExchange
				+ ", currentPrice=" + currentPrice + ", date=" + date + ", time=" + time + "]";
	}

}

package com.example.stockspring.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.example.stockspring.model.IPO;
import com.example.stockspring.model.Sectors;
import com.example.stockspring.service.StockPriceService;

@Controller
public class StockPriceContoller {

	@Autowired
	StockPriceService stockPriceService;

	@ModelAttribute("sector")
	public List<String> setSector() {
		List<String> company = new ArrayList<String>();
		company.add("Company");
		company.add("Sector");

		return company;
	}

	@ModelAttribute("ipo")
	public List<String> setIpo() {
		List<String> ipo = new ArrayList<String>();
		ipo.add("BSE");
		ipo.add("NSE");

		return ipo;
	}

	@RequestMapping(value = "/com", method = RequestMethod.GET)
	public String com(ModelMap model) {
		Sectors sector = new Sectors();
		IPO ipo = new IPO();
		model.addAttribute("ipo", ipo);
		model.addAttribute("c", sector);
		return "ComparisonPage";
	}

	@RequestMapping(value = "/com", method = RequestMethod.POST)
	public String com(@ModelAttribute("c") Model model) {
		return null;
	}

	@RequestMapping(path = "/stockPriceList", method = RequestMethod.GET)
	public ModelAndView stockList() {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("stockPrice");
		mav.addObject("stockPriceList", stockPriceService.stockPriceList());
		return mav;
	}
}

package com.example.stockspring.dao;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.stockspring.model.Company;
import com.example.stockspring.model.StockPrice;

public interface CompanyDao extends JpaRepository<Company, Integer> {
	/*
	 * public Company insertCompany(Company company) throws Exception;
	 * 
	 * public Company updateCompany(Company company);
	 * 
	 * public List<Company> getCompanyList() throws Exception;
	 */

	public List<Company> findBysectorid(int id);

	@Query("select c from Company c where c.companyName like %:letter%")
	public List<Company> findBycompanyName(@Param(value = "letter") String letter);

	
}

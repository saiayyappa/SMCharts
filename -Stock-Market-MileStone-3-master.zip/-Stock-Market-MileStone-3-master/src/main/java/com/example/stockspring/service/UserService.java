package com.example.stockspring.service;

import java.util.Optional;

import com.example.stockspring.model.Userdb;

public interface UserService {

	public Userdb register(Userdb user) throws Exception;

	public Optional<Userdb> login(Integer id);

	
	

}

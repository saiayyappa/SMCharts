package com.example.stockspring.controller;

import java.sql.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.example.stockspring.dao.CompanyDao;
import com.example.stockspring.dao.IpoDao;
import com.example.stockspring.dao.StockPriceDao;
import com.example.stockspring.model.Company;
import com.example.stockspring.model.IPO;
import com.example.stockspring.model.StockPrice;

@RestController
public class companyController1 {

	@Autowired
	CompanyDao repository;

	@Autowired
	StockPriceDao stock;

	@Autowired
	IpoDao ipo;

	@GetMapping(value = "/sector/{id}")
	public List<Company> getCompanyList(@PathVariable int id) {
		List<Company> company = repository.findBysectorid(id);
		return company;
	}

	@GetMapping(value = "/stockprice/{id}")
	public List<StockPrice> stock(@PathVariable int id) {
		List<StockPrice> stockprice = stock.findBycompanyCode(id);

		return stockprice;
	}

	@GetMapping(value = "/ipo/{id}")
	public List<IPO> ipo(@PathVariable int id) {
		List<IPO> Ipo = ipo.findBycompanyCode(id);
		return Ipo;
	}

	@GetMapping(value = "/search/{letter}")
	public List<Company> search1(@PathVariable String letter) {

		List<Company> company = repository.findBycompanyName(letter);
		System.out.println(company);
		return company;
	}
	
	@GetMapping(value="/date/{date1}/{date2}")
	public List<StockPrice> date(@PathVariable Date date1,@PathVariable Date date2)
	{
		List<StockPrice> date=stock.findBydate(date1,date2);
		return date;
		
	}
}

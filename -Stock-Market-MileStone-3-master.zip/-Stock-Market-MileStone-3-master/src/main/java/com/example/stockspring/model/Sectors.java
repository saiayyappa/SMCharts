package com.example.stockspring.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;

@Entity
@Table(name = "sectors")
public class Sectors {

	@Id
	@Column(name = "id")
	private int id;

	@NotEmpty(message = "Please enter sectorName")
	@Pattern(regexp = "^[A-Za-z]+$", message = "SectorName should not contain numbers")
	@Column(name = "sector_name")
	private String sectorName;

	@NotEmpty(message = "Please enter Brief")
	@Pattern(regexp = "^[A-Za-z]+$", message = "Brief should not contain numbers")
	@Column(name = "brief")
	private String brief;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getSectorName() {
		return sectorName;
	}

	public void setSectorName(String sectorName) {
		this.sectorName = sectorName;
	}

	public String getBrief() {
		return brief;
	}

	public void setBrief(String brief) {
		this.brief = brief;
	}
}
